import axios from 'axios'
import { MessageBox, Message } from 'element-ui'
import store from '@/store'
import router from '@/router'
import { getToken } from '@/utils/auth'
axios.defaults.withCredentials = true;
// create an axios instance
const service = axios.create({
  //baseURL:"http://39.98.147.239:8084/container_discern_web", // url = base url + request url 
	//baseURL:"http://192.168.0.199:8080/container_discern_web", // url = base url + request url
	baseURL:"http://web.cnocr.top/container_discern_web", // url = base url + request url
  withCredentials: true, // send cookies when cross-domain requests
  timeout: 5000000000000 ,// request timeout,
	headers: {
			'Content-Type': 'application/json;charset=utf-8',
	},
})

// request interceptor
service.interceptors.request.use(
  config => {
    // do something before request is sent
		if (store.getters.token) {
      // let each request carry token
      // ['X-Token'] is a custom headers key
      // please modify it according to the actual situation
      //config.headers['token'] = getToken()
			console.log(getToken());
			config.headers = {
				'Content-Type': 'application/json;charset=utf-8',
				'token':getToken()
			} 
			//原生获取上传进度的事件
			// config.onUploadProgress=function(progressEvent){
			// 		console.log(progressEvent.loaded);
			// 		console.log("***************");
			// 		console.log(progressEvent.total);
			// 		let complete = (progressEvent.loaded / progressEvent.total * 100 | 0);
			// 		console.log('上传**** ' + complete);
			// }
    }else{
			config.headers = {
				'Content-Type': 'application/json;charset=utf-8',
			} 
		}
		console.log(config);
    return config
  },
  error => {
    // do something with request error
    console.log(error) // for debug
    return Promise.reject(error)
  }
)

// response interceptor
service.interceptors.response.use(
  /**
   * If you want to get http information such as headers or status
   * Please return  response => response
  */

  /**
   * Determine the request status by custom code
   * Here is just an example
   * You can also judge the status by HTTP Status Code
   */
  response => {
    const res = response.data
		console.log(response)
    // if the custom code is not 20000, it is judged as an error.
    if (res.code != 200) {
			if(res.code==405){
				Message({
				  message: "登录信息已过期，请重新登录" || '错误',
				  type: 'error',
				  duration: 2* 1000
				})
				store.dispatch('user/logout')
				//window.location.href="http://localhost:9527/#/login?redirect=%2Fuserlist%2Fuserlist";
				window.location.href="http://baixun.cnocr.top/#/login?redirect=%2Fuserlist%2Fuserlist";
			}else{
				Message({
				  message: res.msg || '错误',
				  type: 'error',
				  duration: 500 * 1000
				})
			}
    } else {
      return res
    }
  },
  error => {
    console.log('err' + error) // for debug
    Message({
      message: error.message,
      type: 'error',
      duration: 5 * 1000
    })
    return Promise.reject(error)
  }
)

export default service
