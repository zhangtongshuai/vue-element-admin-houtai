import request from '@/utils/request'

//登录
export function UserLogin(params) {
	console.log(params)
  return request({
    url:'/loginAdmin',
    method:'post',
    data:params
  })
}
//获取验证码
export function sendMeg() {
  return request({
    url:'/bx-admin/sendMeg.do',
    method:'post'
  })
}
//修改密码
export function editPassword(params) {
	console.log(params)
  return request({
    url:'/bx-admin/editPassword.do',
    method:'post',
    data:params
  })
}

//获取SDK的list
export function getSdkList(params) {
  return request({
    url: '/bx-system-sdk/page.do',
    method: 'post',
    data:params
  })
}


// 添加SDK
export function addSdk(params) {
  return request({
    url: '/bx-system-sdk/edit.do',
    method: 'post',
    data:params
  })
}

//删除SDK卡
export function delSdk(params) {
  return request({
    url: '/bx-system-sdk/remove.do',
    method: 'post',
    data:params
  })
}

//查看SDk详情
export function getDetail(params) {
  return request({
    url: '/bx-system-sdk/detail.do',
    method: 'post',
    data:params
  })
}

//添加充值规则
export function addRechargeRule(params) {
  return request({
    url: '/bx-recharge-rule/edit.do',
    method: 'post',
    data:params
  })
}

//获取充值规则的List
export function getRechargeRule(params) {
  return request({
    url: '/bx-recharge-rule/page.do',
    method: 'post',
    data:params
  })
}

//删除充值规则
export function delRechargeRule(params) {
  return request({
    url: '/bx-recharge-rule/remove.do',
    method: 'post',
    data:params
  })
}

//查看充值规则详情
export function getRuleDetail(params) {
  return request({
    url: '/bx-recharge-rule/detail.do',
    method: 'post',
    data:params
  })
}

//获取充值记录
export function getRechargeRecord(params) {
  return request({
    url: '/bx-recharge-record/page.do',
    method: 'post',
    data:params
  })
}


//获取系统设置
export function getSystem(params) {
  return request({
    url: '/bx-system/detail.do',
    method: 'post',
    data:params
  })
}

//修改系统设置
export function editSystem(params) {
  return request({
    url: '/bx-system/edit.do',
    method: 'post',
    data:params
  })
}

//获取用户信息
export function getUserList(params) {
  return request({
    url: '/bx-user/page.do',
    method: 'post',
    data:params
  })
}

//上传SDK
export function upLoadSDK(params) {
  return request({
    url: 'http://39.98.147.239:8082/file_upload/fileServer/upload',
    method: 'post',
    data:params
  })
}


//封号解封
export function changeUserType(params) {
  return request({
    url: '/bx-user/edit.do',
    method: 'post',
    data:params
  })
}

//获取首页的统计信息
export function getIndexData(params) {
  return request({
    url: '/index/index.do',
    method: 'post',
    data:params
  })
}

