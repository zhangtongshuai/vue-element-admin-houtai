//import JSEncrypt from "@/api/jsencrypt"
import {JSEncrypt} from 'jsencrypt'
export function getJsencryptRestlt(params) {
  var key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5m624eHHu6dC74W6Xu8YGQEA3/U3kzpBxFrXbzK8tuBC2mnBBtn/OAy7IqLMnKuesoElFOUfE82Zx2TBi5xFUuans0V5DyR9AGUiQKcKsbbmLpxyVRE5uo37UkovypRUc0W8I/R3Lc0IGkVeMHXq4O5dknD+N0J/CWgOi04ltEbmIwKU/eRUdjY4QYBI8m9G/N2c4Dy/HzPR53PtpUO8ZwagHuUOTaWb2lNf1oA26TlKDuuRQj3D8NaM+njg+nrL0+8P9bwFDbuqxY5iLWAvh69NrfVN0ldYJm2E//cLV1RybPF0g8gpnf2pyzmJcZ6uWhHCZ0GjQMNDjffaKOYgoQIDAQAB";
  params = params || {};
  var encrypt = new JSEncrypt();
  encrypt.setPublicKey(key);
  params = JSON.stringify(params);
  var d = encrypt.encrypt(params);
  var ps;
  if (params.length > 200) {
    ps = params;
  } else {
    ps = encodeURI(d);
  }
  return ps
}