<template>
  <div class="app-container">
    <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="100px" style="width: 400px; margin-left:50px;">
      <el-form-item label="联系电话" prop="phone">
        <el-input v-model="temp.phone" type="text"/>
      </el-form-item>
      <el-form-item label="赠送类型" prop="type">
				<el-radio v-model="temp.type" label="1">时间</el-radio>
				<el-radio v-model="temp.type" label="2">次数</el-radio>
      </el-form-item>
      <el-form-item label="赠送天数" prop="givenumber" v-if="temp.type=='1'">
        <el-input v-model="temp.givenumber" type="number"/>
      </el-form-item>
			<el-form-item label="赠送次数" prop="givenumber" v-if="temp.type=='2'">
			  <el-input v-model="temp.givenumber" type="number"/>
			</el-form-item>
			<el-form-item label="赠送状态" prop="givestate">
			  <el-switch v-model="temp.givestate"></el-switch>
			</el-form-item>
    </el-form>
		<div slot="footer" class="dialog-footer">
		  <el-button type="primary" @click="updateData()">提交</el-button>
		</div>
  </div>
</template>

<script>
import {getSystem,editSystem} from '@/api/api'
import waves from '@/directive/waves' // waves directive
import { parseTime } from '@/utils'
import { getJsencryptRestlt } from '@/api/getResylt'

export default {
  name: 'Guide',
  data() {
    return {
      temp: {
        id: 1,
				phone: '', //联系电话
				type:'1', //赠送类型
				givenumber:0, //赠送次数
				givestate:false, //赠送状态
      },
      rules: {
				phone: [{ required: true, message: '请输入联系电话', trigger: 'blur' }],
        type: [{ required: true, message: '请选择赠送类型', trigger: 'change' }],
        givenumber: [{required: true, message: '请输入赠送天数/次数', trigger: 'blur' }],
        givestate: [{ required: true, message: '请选择赠送状态', trigger: 'blur' }]
      },
    }
  },
  created() {
		this.getSystemList();
  },
	computed: {
		visitedViews() {
		  return this.$store.state.tagsView.visitedViews
		}
	},
  methods: {
		//关闭选中的开始----------
		closeSelectedTag() {
			var view;
			for(var i=0;i<this.visitedViews.length;i++){
				if(this.isActive(this.visitedViews[i])){
					view=this.visitedViews[i];
				}
			}
			console.log(view);
		  this.$store.dispatch('tagsView/delView', view).then(({ visitedViews }) => {
		    if (this.isActive(view)) {
		      this.toLastView(visitedViews, view)
		    }
		  })
		},
		isActive(route) {
		  return route.path === this.$route.path
		},
		toLastView(visitedViews, view) {
		  const latestView = visitedViews.slice(-1)[0]
		  if (latestView) {
		    this.$router.push(latestView.fullPath)
		  } else {
		    // now the default is to redirect to the home page if there is no tags-view,
		    // you can adjust it according to your needs.
		    if (view.name === 'Dashboard') {
		      // to reload home page
		      this.$router.replace({ path: '/redirect' + view.fullPath })
		    } else {
		      this.$router.push('/')
		    }
		  }
		},
		//关闭选中的结束----------
		//获取系统设置的详情
		getSystemList(){
			getSystem().then((response) => {
				if(response.code==200){
					console.log(response);
					this.temp.phone=response.data.telphone;
					this.temp.type=(response.data.giveType).toString();
					this.temp.givenumber=response.data.giveNumber;
					if(response.data.giveState==0){
						this.temp.givestate=true;
					}else{
						this.temp.givestate=false;
					}
				}
			})
		},
		//修改系统设置
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
					var state;
					console.log(this.temp.givestate);
					if(this.temp.givestate){
						state=0;
					}else{
						state=1
					}
					var data={
						telphone:this.temp.phone,
						giveType:parseInt(this.temp.type),
						giveNumber:this.temp.givenumber,
						giveState:state
					}
					console.log(data);
					editSystem(getJsencryptRestlt(data)).then((response) => {
						if(response.code==200){
							this.$notify({
							  title: '成功',
							  message: '修改系统设置成功',
							  type: 'success',
							  duration: 2000
							})
							this.getSystemList();
						}
          })
        }
      })
    },
  }
}
</script>
<style scoped="scoped">
	.dialog-footer{
		width: 10.666666rem;
	}
	.dialog-footer button{
		margin: 0 auto;
		display: block;
	}
</style>
