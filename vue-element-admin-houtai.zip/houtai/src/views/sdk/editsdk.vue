<template>
  <div class="tinymce-container">
		<div class="app-container">
		  <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="100px" style="width: 800px; margin-left:50px;">
		    <el-form-item label="版本号" prop="versionNum">
		      <el-input v-model="temp.versionNum" type="text"/>
		    </el-form-item>
		    <!-- <el-form-item label="上传" prop="versionUrl">
					<el-button type="primary" :loading="updateLoading" style="position: relative;">
						上传<i class="el-icon-upload el-icon--right"></i>
						<input type="file" id="people-export" ref="inputer" @change="fileUpload" style="width: 100%;height: 100%;position: absolute;top: 0;left: 0;opacity: 0;"/>
					</el-button>
					<div>{{filename}}</div>
		    </el-form-item> -->
				<el-form-item label="URl" prop="url">
				  <el-input v-model="temp.versionUrl" type="text"/>
				</el-form-item>
				<el-form-item label="状态" prop="state">
				  <el-radio v-model="temp.state" label="0">隐藏</el-radio>
				  <el-radio v-model="temp.state" label="1">可用</el-radio>
					<el-radio v-model="temp.state" label="2">不可用</el-radio>
				</el-form-item>
				<el-form-item label="版本说明" prop="content">
				  <textarea :id="tinymceId" v-model="temp.content" class="tinymce-textarea" />
					<div class="editor-custom-btn-container">
					  <editorImage color="#1890ff" class="editor-upload-btn" @successCBK="imageSuccessCBK" />
					</div>
				</el-form-item>
		  </el-form>
			<div slot="footer" class="dialog-footer">
			  <el-button type="primary" @click="updateData()">提交</el-button>
			</div>
		</div>
  </div>
</template>
<script>
	import editorImage from './components/EditorImage'
	import plugins from './plugins'
	import toolbar from './toolbar'
	import load from './dynamicLoadScript'
	import { getJsencryptRestlt } from '@/api/getResylt' //加密的
	import { addSdk,upLoadSDK } from '@/api/api'

const tinymceCDN = 'https://cdn.jsdelivr.net/npm/tinymce-all-in-one@4.9.3/tinymce.min.js'

export default {
  name: 'Tinymce',
  components: { editorImage },
  props: {
    id: {
      type: String,
      default: function() {
        return 'vue-tinymce-' + +new Date() + ((Math.random() * 1000).toFixed(0) + '')
      }
    },
    value: {
      type: String,
      default: ''
    },
    toolbar: {
      type: Array,
      required: false,
      default() {
        return []
      }
    },
    menubar: {
      type: String,
      default: 'file edit insert view format table'
    },
    height: {
      type: [Number, String],
      required: false,
      default: 360
    },
    width: {
      type: [Number, String],
      required: false,
      default: 'auto'
    }
  },
  data() {
    return {
			sdkid:'', //这个SDK的id
			temp: {
				versionNum: '', //版本号
				versionUrl:'', //url
				state:"1", //状态
				content:'', //版本说明
			},
			rules: {
				versionNum: [{ required: true, message: '请输入版本号', trigger: 'blur' }],
				versionUrl: [{ required: true, message: '请输入url', trigger: 'blur' }],
			  state: [{required: true, message: '请选择状态', trigger: 'change' }],
			  content: [{ required: false, message: '请输入版本说明', trigger: 'blur' }]
			},
      hasChange: false,
      hasInit: false,
      tinymceId: this.id,
      fullscreen: false,
      languageTypeList: {
        'en': 'en',
        'zh': 'zh_CN',
        'es': 'es_MX',
        'ja': 'ja'
      },
			filename:'', //文件名称
			updateLoading:false
    }
  },
  computed: {
		visitedViews() {
		  return this.$store.state.tagsView.visitedViews
		},
    containerWidth() {
      const width = this.width
      if (/^[\d]+(\.[\d]+)?$/.test(width)) { // matches `100`, `'100'`
        return `${width}px`
      }
      return width
    }
  },
  watch: {
    value(val) {
      if (!this.hasChange && this.hasInit) {
        this.$nextTick(() =>
          window.tinymce.get(this.tinymceId).setContent(val || ''))
      }
    }
  },
  mounted() {
    this.init();
		//接收传值
		let sdkinfo = JSON.parse(this.$Base64.decode(this.$route.query.c));
		console.log(sdkinfo);
		this.sdkid = sdkinfo.id;
		this.temp.versionNum = sdkinfo.versionNum;
		this.temp.versionUrl = sdkinfo.versionUrl;
		this.temp.state = (sdkinfo.state).toString();
		this.temp.content = sdkinfo.content;
		this.filename=sdkinfo.versionUrl;
		window.tinymce.get(this.tinymceId).insertContent(sdkinfo.content)
  },
  activated() {
    if (window.tinymce) {
      this.initTinymce()
    }
  },
  deactivated() {
    this.destroyTinymce()
  },
  destroyed() {
    this.destroyTinymce()
  },
  methods: {
		//关闭选中的开始----------
		closeSelectedTag() {
			var view;
			for(var i=0;i<this.visitedViews.length;i++){
				if(this.isActive(this.visitedViews[i])){
					view=this.visitedViews[i];
				}
			}
			console.log(view);
		  this.$store.dispatch('tagsView/delView', view).then(({ visitedViews }) => {
		    if (this.isActive(view)) {
		      this.toLastView(visitedViews, view)
		    }
		  })
		},
		isActive(route) {
		  return route.path === this.$route.path
		},
		toLastView(visitedViews, view) {
		  const latestView = visitedViews.slice(-1)[0]
		  if (latestView) {
		    this.$router.push(latestView.fullPath)
		  } else {
		    // now the default is to redirect to the home page if there is no tags-view,
		    // you can adjust it according to your needs.
		    if (view.name === 'Dashboard') {
		      // to reload home page
		      this.$router.replace({ path: '/redirect' + view.fullPath })
		    } else {
		      this.$router.push('/')
		    }
		  }
		},
		//关闭选中的结束----------
    init() {
      // dynamic load tinymce from cdn
      load(tinymceCDN, (err) => {
        if (err) {
          this.$message.error(err.message)
          return
        }
        this.initTinymce()
      })
    },
    initTinymce() {
      const _this = this
      window.tinymce.init({
        selector: `#${this.tinymceId}`,
        language: this.languageTypeList['en'],
        height: this.height,
        body_class: 'panel-body ',
        object_resizing: false,
        toolbar: this.toolbar.length > 0 ? this.toolbar : toolbar,
        menubar: this.menubar,
        plugins: plugins,
        end_container_on_empty_block: true,
        powerpaste_word_import: 'clean',
        code_dialog_height: 450,
        code_dialog_width: 1000,
        advlist_bullet_styles: 'square',
        advlist_number_styles: 'default',
        imagetools_cors_hosts: ['www.tinymce.com', 'codepen.io'],
        default_link_target: '_blank',
        link_title: false,
        nonbreaking_force_tab: true, // inserting nonbreaking space &nbsp; need Nonbreaking Space Plugin
        init_instance_callback: editor => {
          if (_this.value) {
            editor.setContent(_this.value)
          }
          _this.hasInit = true
          editor.on('NodeChange Change KeyUp SetContent', () => {
            this.hasChange = true
            this.$emit('input', editor.getContent())
          })
        },
        setup(editor) {
          editor.on('FullscreenStateChanged', (e) => {
            _this.fullscreen = e.state
          })
        }
      })
    },
    destroyTinymce() {
      const tinymce = window.tinymce.get(this.tinymceId)
      if (this.fullscreen) {
        tinymce.execCommand('mceFullScreen')
      }

      if (tinymce) {
        tinymce.destroy()
      }
    },
    setContent(value) {
      window.tinymce.get(this.tinymceId).setContent(value)
    },
    getContent() {
      window.tinymce.get(this.tinymceId).getContent()
    },
    imageSuccessCBK(arr) {
      const _this = this
      arr.forEach(v => {
        window.tinymce.get(_this.tinymceId).insertContent(`<img class="wscnph" src="${v.url}" >`)
      })
    },
		//上传文件
		fileUpload(event){
		  let file = event.target.files
		  let formData = new FormData();
		  formData.append('file', file[0])
			this.filename=file[0].name;
		  console.log(formData);
			this.updateLoading=true;
			upLoadSDK(formData).then((response) => {
				console.log(response);
				this.updateLoading=false;
				if(response.code==200){
					this.$message({
						message: '上传成功',
						type: 'success'
					});
					this.temp.versionUrl=response.data.fileUrl;
				}
			})
		},
		//添加提交SDk
		updateData() {
			window.tinymce.get(this.tinymceId).getContent(); //这就是富文本中的内容
			console.log(window.tinymce.get(this.tinymceId).getContent()); //这就是富文本中的内容
			var data={
				id:this.sdkid,
				versionNum:this.temp.versionNum,
				versionUrl:this.temp.versionUrl,
				content:window.tinymce.get(this.tinymceId).getContent(),
				state:this.temp.state
			}
		  this.$refs['dataForm'].validate((valid) => {
		    if (valid) {
					addSdk(getJsencryptRestlt(data)).then((response) => {
						if(response.code==200){
							console.log(response);
							this.$notify({
							  title: '成功',
							  message: '修改成功',
							  type: 'success',
							  duration: 2000
							});
							setTimeout(() => {
								this.closeSelectedTag();
							}, 1.2 * 1000)
						}
		      })
		    }
		  })
		},
  }
}
</script>

<style scoped>
.dialog-footer{
	width: 10.666666rem;
}
.dialog-footer button{
	margin: 0 auto;
	display: block;
}
.tinymce-container {
  position: relative;
  line-height: normal;
}
.tinymce-container>>>.mce-fullscreen {
  z-index: 10000;
}
.tinymce-textarea {
	width: 500px;
  visibility: hidden;
  z-index: -1;
}
.editor-custom-btn-container {
  position: absolute;
  right: 4px;
  top: 4px;
  /*z-index: 2005;*/
}
.fullscreen .editor-custom-btn-container {
  z-index: 10000;
  position: fixed;
}
.editor-upload-btn {
  display: inline-block;
}
</style>
