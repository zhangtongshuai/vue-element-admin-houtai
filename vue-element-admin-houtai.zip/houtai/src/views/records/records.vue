<template>
  <div class="app-container">
		<el-row :gutter="20">
			<el-col :xs="24" :sm="24" :md="5" :lg="5" :xl="5" style="margin-bottom: 20px;">
				<el-input v-model="search.username" placeholder="请输入账号"></el-input>
			</el-col>
			<el-col :xs="24" :sm="24" :md="5" :lg="5" :xl="5" style="margin-bottom: 20px;">
				<el-input v-model="search.payOrderno" placeholder="请输入支付单号"></el-input>
			</el-col>
			<el-col :xs="24" :sm="24" :md="5" :lg="5" :xl="5" style="margin-bottom: 20px;">
				<el-input v-model="search.orderno" placeholder="请输入订单号"></el-input>
			</el-col>
			<el-col :xs="24" :sm="24" :md="3" :lg="3" :xl="3" style="margin-bottom: 20px;">
				<el-select v-model="search.paytype" placeholder="支付方式">
					<el-option label="全部" value="-1"></el-option>
					<el-option label="微信支付" value="1"></el-option>
					<el-option label="支付宝支付" value="2"></el-option>
				</el-select>
			</el-col>
			<el-col :xs="24" :sm="24" :md="2" :lg="2" :xl="2" style="margin-bottom: 20px;">
				<el-button type="primary" @click="getList">查询</el-button>
			</el-col>
		</el-row>
    <el-table
      :key="tableKey"
      v-loading="listLoading"
      :data="list"
      border
      fit
      highlight-current-row
      style="width: 100%;"
      @sort-change="sortChange"
    >
      <el-table-column label="用户账号" prop="id" align="center" >
        <template slot-scope="scope">
          <span>{{ scope.row.username }}</span>
        </template>
      </el-table-column>
			<el-table-column label="订单号" align="center">
			  <template slot-scope="scope">
			    <span>{{ scope.row.orderno }}</span>
			  </template>
			</el-table-column>
			<el-table-column label="类型" align="center">
			  <template slot-scope="scope">
			    <span v-if="scope.row.type==1">时间</span>
			    <span v-if="scope.row.type==2">次数</span>
			  </template>
			</el-table-column>
			<el-table-column label="天数/次数" align="center">
			  <template slot-scope="scope">
					<span v-if="scope.row.type==1">{{scope.row.number}}天</span>
			    <span v-if="scope.row.type==2">{{scope.row.number}}次</span>
			  </template>
			</el-table-column>
			<el-table-column label="金额" align="center">
			  <template slot-scope="scope">
			    <span>{{scope.row.money}}元</span>
			  </template>
			</el-table-column>
			<el-table-column label="实付金额" align="center">
			  <template slot-scope="scope">
			    <span>{{scope.row.paymoney}}元</span>
			  </template>
			</el-table-column>
			<el-table-column label="支付单号" align="center">
			  <template slot-scope="scope">
			    <span>{{scope.row.payOrderno}}</span>
			  </template>
			</el-table-column>
			<el-table-column label="支付方式" align="center">
			  <template slot-scope="scope">
			    <span v-if="scope.row.paytype==1">微信支付</span>
					<span v-if="scope.row.paytype==2">支付宝支付</span>
			  </template>
			</el-table-column>
			<el-table-column label="支付时间" align="center">
			  <template slot-scope="scope">
			    <span v-if="scope.row.paytime!=null">
						{{ scope.row.paytime | parseTime('{y}-{m}-{d} {h}:{i}:{s}') }}
					</span>
					<span v-if="scope.row.paytime==null">未支付</span>
			  </template>
			</el-table-column>
			<el-table-column label="创建时间" align="center">
			  <template slot-scope="scope">
			    <span>{{ scope.row.addtime | parseTime('{y}-{m}-{d} {h}:{i}:{s}') }}</span>
			  </template>
			</el-table-column>
      <el-table-column label="状态" class-name="status-col">
        <template slot-scope="scope">
					<el-tag v-if="scope.row.state==0" type="info">取消付款</el-tag>
					<el-tag v-if="scope.row.state==1" type="danger">待付款</el-tag>
					<el-tag v-if="scope.row.state==2">已付款</el-tag>
        </template>
      </el-table-column>
    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="pageNo" :limit.sync="pageSize" @pagination="getList" />

    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
      <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="70px" style="width: 400px; margin-left:50px;">
        <el-form-item label="Type" prop="type">
          <el-select v-model="temp.type" class="filter-item" placeholder="Please select">
            <el-option v-for="item in calendarTypeOptions" :key="item.key" :label="item.display_name" :value="item.key" />
          </el-select>
        </el-form-item>
        <el-form-item label="Date" prop="timestamp">
          <el-date-picker v-model="temp.timestamp" type="datetime" placeholder="Please pick a date" />
        </el-form-item>
        <el-form-item label="Title" prop="title">
          <el-input v-model="temp.title" />
        </el-form-item>
        <el-form-item label="Status">
          <el-select v-model="temp.status" class="filter-item" placeholder="Please select">
            <el-option v-for="item in statusOptions" :key="item" :label="item" :value="item" />
          </el-select>
        </el-form-item>
        <el-form-item label="Imp">
          <el-rate v-model="temp.importance" :colors="['#99A9BF', '#F7BA2A', '#FF9900']" :max="3" style="margin-top:8px;" />
        </el-form-item>
        <el-form-item label="Remark">
          <el-input v-model="temp.remark" :autosize="{ minRows: 2, maxRows: 4}" type="textarea" placeholder="Please input" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">
          Cancel
        </el-button>
        <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">
          Confirm
        </el-button>
      </div>
    </el-dialog>

    <el-dialog :visible.sync="dialogPvVisible" title="Reading statistics">
      <el-table :data="pvData" border fit highlight-current-row style="width: 100%">
        <el-table-column prop="key" label="Channel" />
        <el-table-column prop="pv" label="Pv" />
      </el-table>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogPvVisible = false">Confirm</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { getRechargeRecord} from '@/api/api' 
import { getJsencryptRestlt } from '@/api/getResylt'
import waves from '@/directive/waves' // waves directive
import { parseTime } from '@/utils'
import Pagination from '@/components/Pagination' // secondary package based on el-pagination

const calendarTypeOptions = [
  { key: 'CN', display_name: 'China' },
  { key: 'US', display_name: 'USA' },
  { key: 'JP', display_name: 'Japan' },
  { key: 'EU', display_name: 'Eurozone' }
]

// arr to obj, such as { CN : "China", US : "USA" }
const calendarTypeKeyValue = calendarTypeOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name
  return acc
}, {})

export default {
  name: 'ComplexTable',
  components: { Pagination },
  directives: { waves },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'info',
        deleted: 'danger'
      }
      return statusMap[status]
    },
    typeFilter(type) {
      return calendarTypeKeyValue[type]
    }
  },
  data() {
    return {
      tableKey: 0,
      list: null,
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 20,
        importance: undefined,
        title: undefined,
        type: undefined,
        sort: '+id'
      },
      importanceOptions: [1, 2, 3],
      calendarTypeOptions,
      sortOptions: [{ label: 'ID Ascending', key: '+id' }, { label: 'ID Descending', key: '-id' }],
      statusOptions: ['published', 'draft', 'deleted'],
      showReviewer: false,
      temp: {
        id: undefined,
        importance: 1,
        remark: '',
        timestamp: new Date(),
        title: '',
        type: '',
        status: 'published'
      },
      dialogFormVisible: false,
      dialogStatus: '',
      textMap: {
        update: 'Edit',
        create: 'Create'
      },
      dialogPvVisible: false,
      pvData: [],
      rules: {
        type: [{ required: true, message: 'type is required', trigger: 'change' }],
        timestamp: [{ type: 'date', required: true, message: 'timestamp is required', trigger: 'change' }],
        title: [{ required: true, message: 'title is required', trigger: 'blur' }]
      },
      downloadLoading: false,
			pageNo:1, //页数
			pageSize:10 ,//一页有多少
			search:{
				username:'',
				paytype:'',
				payOrderno:'',
				orderno:''
			}
    }
  },
  created() {
    this.getList();  //获取充值记录
  },
  methods: {
    getList() {
      this.listLoading = true;
			var paytype;
			if(this.search.paytype=="-1"){
				paytype=""
			}else{
				paytype=this.search.paytype
			}
			var data={
				pageNo:this.pageNo,
				pageSize:this.pageSize,
				username:this.search.username,
				paytype:paytype,
				payOrderno:this.search.payOrderno,
				orderno:this.search.orderno
			}
			console.log("吱吱吱吱自");
			console.log(data);
      getRechargeRecord(getJsencryptRestlt(data)).then(response => {
        this.list = response.data.records; //列表内容
        this.total = response.data.total;
        setTimeout(() => {
        	this.listLoading = false
        }, 0 * 1000)
      })
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    handleModifyStatus(row, status) {
      this.$message({
        message: '操作Success',
        type: 'success'
      })
      row.status = status
    },
    sortChange(data) {
      const { prop, order } = data
      if (prop === 'id') {
        this.sortByID(order)
      }
    },
    sortByID(order) {
      if (order === 'ascending') {
        this.listQuery.sort = '+id'
      } else {
        this.listQuery.sort = '-id'
      }
      this.handleFilter()
    },
    resetTemp() {
      this.temp = {
        id: undefined,
        importance: 1,
        remark: '',
        timestamp: new Date(),
        title: '',
        status: 'published',
        type: ''
      }
    },
    handleCreate() {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          this.temp.id = parseInt(Math.random() * 100) + 1024 // mock a id
          this.temp.author = 'vue-element-admin'
          createArticle(this.temp).then(() => {
            this.list.unshift(this.temp)
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Created Successfully',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleUpdate(row) {
      this.temp = Object.assign({}, row) // copy obj
      this.temp.timestamp = new Date(this.temp.timestamp)
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          tempData.timestamp = +new Date(tempData.timestamp) // change Thu Nov 30 2017 16:41:05 GMT+0800 (CST) to 1512031311464
          updateArticle(tempData).then(() => {
            for (const v of this.list) {
              if (v.id === this.temp.id) {
                const index = this.list.indexOf(v)
                this.list.splice(index, 1, this.temp)
                break
              }
            }
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Update Successfully',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleDelete(row) {
      this.$notify({
        title: 'Success',
        message: 'Delete Successfully',
        type: 'success',
        duration: 2000
      })
      const index = this.list.indexOf(row)
      this.list.splice(index, 1)
    },
    handleFetchPv(pv) {
      fetchPv(pv).then(response => {
        this.pvData = response.data.pvData
        this.dialogPvVisible = true
      })
    },
    handleDownload() {
      this.downloadLoading = true
      import('@/vendor/Export2Excel').then(excel => {
        const tHeader = ['timestamp', 'title', 'type', 'importance', 'status']
        const filterVal = ['timestamp', 'title', 'type', 'importance', 'status']
        const data = this.formatJson(filterVal, this.list)
        excel.export_json_to_excel({
          header: tHeader,
          data,
          filename: 'table-list'
        })
        this.downloadLoading = false
      })
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => {
        if (j === 'timestamp') {
          return parseTime(v[j])
        } else {
          return v[j]
        }
      }))
    },
    getSortClass: function(key) {
      const sort = this.listQuery.sort
      return sort === `+${key}`
        ? 'ascending'
        : sort === `-${key}`
          ? 'descending'
          : ''
    }
  }
}
</script>
