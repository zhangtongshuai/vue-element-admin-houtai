<template>
  <div class="app-container">
		<el-row :gutter="20">
			<el-col :xs="24" :sm="24" :md="5" :lg="5" :xl="5" style="margin-bottom: 20px;">
				<el-input v-model="search.username" placeholder="请输入账号"></el-input>
			</el-col>
			<el-col :xs="24" :sm="24" :md="5" :lg="5" :xl="5" style="margin-bottom: 20px;">
				<el-input  v-model="search.telphone" placeholder="请输入手机号"></el-input>
			</el-col>
			<el-col :xs="24" :sm="24" :md="5" :lg="5" :xl="5" style="margin-bottom: 20px;">
				<el-input v-model="search.realname" placeholder="请输入联系人"></el-input>
			</el-col>
			<el-col :xs="24" :sm="24" :md="2" :lg="2" :xl="2" style="margin-bottom: 20px;">
				<el-button type="primary" @click="getList">查询</el-button>
			</el-col>
		</el-row>
    <el-table
      :key="tableKey"
      v-loading="listLoading"
      :data="list"
      border
      fit
      highlight-current-row
      style="width: 100%;"
      @sort-change="sortChange"
    >
      <el-table-column label="账号" prop="id" align="center" >
        <template slot-scope="scope">
          <span>{{ scope.row.username }}</span>
        </template>
      </el-table-column>
			<el-table-column label="手机号" align="center">
			  <template slot-scope="scope">
			    <span>{{ scope.row.telphone }}</span>
			  </template>
			</el-table-column>
			<el-table-column label="用户类型" align="center">
			  <template slot-scope="scope">
			    <span v-if="scope.row.type==0">体验用户</span>
			    <span v-if="scope.row.type==1">正式用户</span>
			  </template>
			</el-table-column>
			<el-table-column label="联系人" align="center">
			  <template slot-scope="scope">
					<span>{{ scope.row.realname }}</span>
			  </template>
			</el-table-column>
			<el-table-column label="已使用次数" align="center">
			  <template slot-scope="scope">
			    <span>{{scope.row.userNum}}</span>
			  </template>
			</el-table-column>
			<el-table-column label="剩余次数" align="center">
			  <template slot-scope="scope">
			    <span>{{scope.row.surplusNum}}</span>
			  </template>
			</el-table-column>
			<el-table-column label="注册时间" align="center">
			  <template slot-scope="scope">
			    <span>
						{{ scope.row.addtime | parseTime('{y}-{m}-{d} {h}:{i}:{s}') }}
					</span>
			  </template>
			</el-table-column>
			<el-table-column label="到期时间" align="center">
			  <template slot-scope="scope">
			    <span v-if="scope.row.duetime!=null">{{ scope.row.duetime | parseTime('{y}-{m}-{d} {h}:{i}:{s}') }}</span>
					<span v-if="scope.row.duetime==null"></span>
			  </template>
			</el-table-column>
      <el-table-column label="状态" class-name="status-col">
        <template slot-scope="scope">
					<el-tag v-if="scope.row.status==0">正常</el-tag>
					<el-tag v-if="scope.row.status==1" type="danger">封号</el-tag>
        </template>
      </el-table-column>
			<el-table-column label="操作" class-name="status-col">
			  <template slot-scope="scope">
					<el-button v-if="scope.row.status==0" size="mini" type="danger" @click="changeUserType(1,scope.row.id)">封号</el-button>
					<el-button v-if="scope.row.status==1" type="primary" size="mini" @click="changeUserType(0,scope.row.id)">解封</el-button>
			  </template>
			</el-table-column>
    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="pageNo" :limit.sync="pageSize" @pagination="getList" />

  </div>
</template>

<script>
import { getUserList,changeUserType} from '@/api/api' 
import { getJsencryptRestlt } from '@/api/getResylt'
import waves from '@/directive/waves' // waves directive
import { parseTime } from '@/utils'
import Pagination from '@/components/Pagination' // secondary package based on el-pagination

const calendarTypeOptions = [
  { key: 'CN', display_name: 'China' },
  { key: 'US', display_name: 'USA' },
  { key: 'JP', display_name: 'Japan' },
  { key: 'EU', display_name: 'Eurozone' }
]

// arr to obj, such as { CN : "China", US : "USA" }
const calendarTypeKeyValue = calendarTypeOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name
  return acc
}, {})

export default {
  name: 'ComplexTable',
  components: { Pagination },
  directives: { waves },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'info',
        deleted: 'danger'
      }
      return statusMap[status]
    },
    typeFilter(type) {
      return calendarTypeKeyValue[type]
    }
  },
  data() {
    return {
      tableKey: 0,
      list: null,
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 20,
        importance: undefined,
        title: undefined,
        type: undefined,
        sort: '+id'
      },
      importanceOptions: [1, 2, 3],
      calendarTypeOptions,
      sortOptions: [{ label: 'ID Ascending', key: '+id' }, { label: 'ID Descending', key: '-id' }],
      statusOptions: ['published', 'draft', 'deleted'],
      showReviewer: false,
      temp: {
        id: undefined,
        importance: 1,
        remark: '',
        timestamp: new Date(),
        title: '',
        type: '',
        status: 'published'
      },
      dialogFormVisible: false,
      dialogStatus: '',
      textMap: {
        update: 'Edit',
        create: 'Create'
      },
      dialogPvVisible: false,
      pvData: [],
      rules: {
        type: [{ required: true, message: 'type is required', trigger: 'change' }],
        timestamp: [{ type: 'date', required: true, message: 'timestamp is required', trigger: 'change' }],
        title: [{ required: true, message: 'title is required', trigger: 'blur' }]
      },
      downloadLoading: false,
			pageNo:1, //页数
			pageSize:10,//一页有多少
			search:{
				username:'',
				telphone:'',
				realname:''
			}
    }
  },
  created() {
    this.getList();  //获取充值记录
  },
  methods: {
    getList() {
      this.listLoading = true;
			var data={
				pageNo:this.pageNo,
				pageSize:this.pageSize,
				username:this.search.username,
				telphone:this.search.telphone,
				realname:this.search.realname
			}
			console.log("传值");
			console.log(data);
      getUserList(getJsencryptRestlt(data)).then(response => {
        this.list = response.data.records; //列表内容
        this.total = response.data.total;
				console.log("下面是获取的用户--------------");
				console.log(response.data.records);
        setTimeout(() => {
        	this.listLoading = false
        }, 0 * 1000)
      })
    },
		//封号解封
		changeUserType(status,id){
			var data={
				id:id,
				status:status
			}
			console.log(data);
			changeUserType(getJsencryptRestlt(data)).then(response => {
				console.log(response);
				if(response.code==200){
					this.$message({
					  message: '修改成功',
					  type: 'success',
						duration: 2* 1000
					});
					this.getList();  //获取充值记录
				}
			})
		},
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    handleModifyStatus(row, status) {
      this.$message({
        message: '操作Success',
        type: 'success',
      })
      row.status = status
    },
    sortChange(data) {
      const { prop, order } = data
      if (prop === 'id') {
        this.sortByID(order)
      }
    },
    sortByID(order) {
      if (order === 'ascending') {
        this.listQuery.sort = '+id'
      } else {
        this.listQuery.sort = '-id'
      }
      this.handleFilter()
    },
    resetTemp() {
      this.temp = {
        id: undefined,
        importance: 1,
        remark: '',
        timestamp: new Date(),
        title: '',
        status: 'published',
        type: ''
      }
    },
    handleCreate() {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          this.temp.id = parseInt(Math.random() * 100) + 1024 // mock a id
          this.temp.author = 'vue-element-admin'
          createArticle(this.temp).then(() => {
            this.list.unshift(this.temp)
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Created Successfully',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleUpdate(row) {
      this.temp = Object.assign({}, row) // copy obj
      this.temp.timestamp = new Date(this.temp.timestamp)
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          tempData.timestamp = +new Date(tempData.timestamp) // change Thu Nov 30 2017 16:41:05 GMT+0800 (CST) to 1512031311464
          updateArticle(tempData).then(() => {
            for (const v of this.list) {
              if (v.id === this.temp.id) {
                const index = this.list.indexOf(v)
                this.list.splice(index, 1, this.temp)
                break
              }
            }
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Update Successfully',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleDelete(row) {
      this.$notify({
        title: 'Success',
        message: 'Delete Successfully',
        type: 'success',
        duration: 2000
      })
      const index = this.list.indexOf(row)
      this.list.splice(index, 1)
    },
    handleFetchPv(pv) {
      fetchPv(pv).then(response => {
        this.pvData = response.data.pvData
        this.dialogPvVisible = true
      })
    },
    handleDownload() {
      this.downloadLoading = true
      import('@/vendor/Export2Excel').then(excel => {
        const tHeader = ['timestamp', 'title', 'type', 'importance', 'status']
        const filterVal = ['timestamp', 'title', 'type', 'importance', 'status']
        const data = this.formatJson(filterVal, this.list)
        excel.export_json_to_excel({
          header: tHeader,
          data,
          filename: 'table-list'
        })
        this.downloadLoading = false
      })
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => {
        if (j === 'timestamp') {
          return parseTime(v[j])
        } else {
          return v[j]
        }
      }))
    },
    getSortClass: function(key) {
      const sort = this.listQuery.sort
      return sort === `+${key}`
        ? 'ascending'
        : sort === `-${key}`
          ? 'descending'
          : ''
    }
  }
}
</script>
