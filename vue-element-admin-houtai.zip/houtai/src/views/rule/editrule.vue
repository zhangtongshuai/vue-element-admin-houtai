<template>
  <div class="tinymce-container">
		<div class="app-container">
		  <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="100px" style="width: 800px; margin-left:50px;">
		    <el-form-item label="标题" prop="title">
		      <el-input v-model="temp.title" type="text"/>
		    </el-form-item>
				<el-form-item label="类型" prop="type">
				  <el-radio v-model="temp.type" label="1">时间</el-radio>
				  <el-radio v-model="temp.type" label="2">次数</el-radio>
				</el-form-item>
		    <el-form-item label="天数" prop="number" v-if="temp.type=='1'">
					<el-input v-model="temp.number" type="text"/>
		    </el-form-item>
				<el-form-item label="次数" prop="number" v-if="temp.type=='2'">
					<el-input v-model="temp.number" type="text"/>
				</el-form-item>
				<el-form-item label="原价" prop="originalPrice">
					<el-input v-model="temp.originalPrice" type="text"/>
				</el-form-item>
				<el-form-item label="金额" prop="money">
					<el-input v-model="temp.money" type="text"/>
				</el-form-item>
				<el-form-item label="状态" prop="state">
				  <el-radio v-model="temp.state" label="0">开启</el-radio>
				  <el-radio v-model="temp.state" label="1">关闭</el-radio>
				</el-form-item>
				<el-form-item label="是否最划算" prop="costEffective">
				  <el-radio v-model="temp.costEffective" label="0">否</el-radio>
				  <el-radio v-model="temp.costEffective" label="1">是</el-radio>
				</el-form-item>
				<el-form-item label="内容" prop="content">
				  <el-input type="textarea" v-model="temp.content" placeholder="请输入描述"></el-input>
				</el-form-item>
		  </el-form>
			<div slot="footer" class="dialog-footer">
			  <el-button type="primary" @click="updateData()">提交</el-button>
			</div>
		</div>
  </div>
</template>
<script>
	import {addRechargeRule} from '@/api/api'
	import {getJsencryptRestlt} from "@/api/getResylt"
	import editorImage from './components/EditorImage'
	import plugins from './plugins'
	import toolbar from './toolbar'
	import load from './dynamicLoadScript'

const tinymceCDN = 'https://cdn.jsdelivr.net/npm/tinymce-all-in-one@4.9.3/tinymce.min.js'

export default {
  name: 'addrule',
  components: { editorImage },
  props: {
    id: {
      type: String,
      default: function() {
        return 'vue-tinymce-' + +new Date() + ((Math.random() * 1000).toFixed(0) + '')
      }
    },
    value: {
      type: String,
      default: ''
    },
    toolbar: {
      type: Array,
      required: false,
      default() {
        return []
      }
    },
    menubar: {
      type: String,
      default: 'file edit insert view format table'
    },
    height: {
      type: [Number, String],
      required: false,
      default: 360
    },
    width: {
      type: [Number, String],
      required: false,
      default: 'auto'
    }
  },
  data() {
    return {
			temp: {
				title: '', //标题
				type:'1', //类型
				number:0,  //天数或次数
				originalPrice:0, //原价
				money:0, //金额
				state:"1", //状态
				costEffective:'0', //是否最划算
				content:'', //版本说明
			},
			rules: {
				title: [{ required: true, message: '请输入标题', trigger: 'blur' }],
			  type: [{ required: true, message: '请选择类型', trigger: 'change' }],
				number: [{ required: true, message: '请输入天数/次数', trigger: 'blur' }],
				originalPrice: [{ required: true, message: '请输入原价', trigger: 'blur' }],
				money: [{ required: true, message: '请输入金额', trigger: 'blur' }],
			  state: [{required: true, message: '请选择状态', trigger: 'change' }],
				costEffective: [{required: true, message: '请选择是否为最划算', trigger: 'change' }]
			},
      hasChange: false,
      hasInit: false,
      tinymceId: this.id,
      fullscreen: false,
      languageTypeList: {
        'en': 'en',
        'zh': 'zh_CN',
        'es': 'es_MX',
        'ja': 'ja'
      },
			ruleid:''
    }
  },
  computed: {
		visitedViews() {
		  return this.$store.state.tagsView.visitedViews
		},
    containerWidth() {
      const width = this.width
      if (/^[\d]+(\.[\d]+)?$/.test(width)) { // matches `100`, `'100'`
        return `${width}px`
      }
      return width
    }
  },
  watch: {
    value(val) {
      if (!this.hasChange && this.hasInit) {
        this.$nextTick(() =>
          window.tinymce.get(this.tinymceId).setContent(val || ''))
      }
    }
  },
  mounted() {
    this.init();
		//接收传值
		//let ruleinfo = this.$route.params.ruleinfo;
		let ruleinfo = JSON.parse(this.$Base64.decode(this.$route.query.c));
		console.log(ruleinfo);
		this.ruleid = ruleinfo.id;
		this.temp.title = ruleinfo.title;
		this.temp.type = (ruleinfo.type).toString();
		this.temp.number =ruleinfo.number;
		this.temp.originalPrice = ruleinfo.originalPrice;
		this.temp.money = ruleinfo.money;
		this.temp.state = (ruleinfo.state).toString();
		if(ruleinfo.costEffective){
			this.temp.costEffective="1";
		}else{
			this.temp.costEffective="0";
		}
		this.temp.content = ruleinfo.content;
		//window.tinymce.get(this.tinymceId).insertContent(ruleinfo.content)
  },
  activated() {
    if (window.tinymce) {
      this.initTinymce()
    }
  },
  deactivated() {
    this.destroyTinymce()
  },
  destroyed() {
    this.destroyTinymce()
  },
  methods: {
		//关闭选中的开始----------
		closeSelectedTag() {
			var view;
			for(var i=0;i<this.visitedViews.length;i++){
				if(this.isActive(this.visitedViews[i])){
					view=this.visitedViews[i];
				}
			}
			console.log(view);
		  this.$store.dispatch('tagsView/delView', view).then(({ visitedViews }) => {
		    if (this.isActive(view)) {
		      this.toLastView(visitedViews, view)
		    }
		  })
		},
		isActive(route) {
		  return route.path === this.$route.path
		},
		toLastView(visitedViews, view) {
		  const latestView = visitedViews.slice(-1)[0]
		  if (latestView) {
		    this.$router.push(latestView.fullPath)
		  } else {
		    // now the default is to redirect to the home page if there is no tags-view,
		    // you can adjust it according to your needs.
		    if (view.name === 'Dashboard') {
		      // to reload home page
		      this.$router.replace({ path: '/redirect' + view.fullPath })
		    } else {
		      this.$router.push('/')
		    }
		  }
		},
		//关闭选中的结束----------
    init() {
      // dynamic load tinymce from cdn
      load(tinymceCDN, (err) => {
        if (err) {
          this.$message.error(err.message)
          return
        }
        this.initTinymce()
      })
    },
    initTinymce() {
      const _this = this
      window.tinymce.init({
        selector: `#${this.tinymceId}`,
        language: this.languageTypeList['en'],
        height: this.height,
        body_class: 'panel-body ',
        object_resizing: false,
        toolbar: this.toolbar.length > 0 ? this.toolbar : toolbar,
        menubar: this.menubar,
        plugins: plugins,
        end_container_on_empty_block: true,
        powerpaste_word_import: 'clean',
        code_dialog_height: 450,
        code_dialog_width: 1000,
        advlist_bullet_styles: 'square',
        advlist_number_styles: 'default',
        imagetools_cors_hosts: ['www.tinymce.com', 'codepen.io'],
        default_link_target: '_blank',
        link_title: false,
        nonbreaking_force_tab: true, // inserting nonbreaking space &nbsp; need Nonbreaking Space Plugin
        init_instance_callback: editor => {
          if (_this.value) {
            editor.setContent(_this.value)
          }
          _this.hasInit = true
          editor.on('NodeChange Change KeyUp SetContent', () => {
            this.hasChange = true
            this.$emit('input', editor.getContent())
          })
        },
        setup(editor) {
          editor.on('FullscreenStateChanged', (e) => {
            _this.fullscreen = e.state
          })
        }
      })
    },
    destroyTinymce() {
      const tinymce = window.tinymce.get(this.tinymceId)
      if (this.fullscreen) {
        tinymce.execCommand('mceFullScreen')
      }
      if (tinymce) {
        tinymce.destroy()
      }
    },
    setContent(value) {
      window.tinymce.get(this.tinymceId).setContent(value)
    },
    getContent() {
      window.tinymce.get(this.tinymceId).getContent()
    },
    imageSuccessCBK(arr) {
      const _this = this
      arr.forEach(v => {
        window.tinymce.get(_this.tinymceId).insertContent(`<img class="wscnph" src="${v.url}" >`)
      })
    },
		updateData() {
		  this.$refs['dataForm'].validate((valid) => {
		    if (valid) {
					var costEffective;
					if(this.temp.costEffective=="0"){
						costEffective=false;
					}else {
						costEffective=true;
					}
					var data={
						id:this.ruleid,
						title:this.temp.title,
						type:parseInt(this.temp.type),
						number:parseInt(this.temp.number), 
						money:this.temp.money,
						state:parseInt(this.temp.state),
						originalPrice:this.temp.originalPrice,
						costEffective:costEffective,
						content:this.temp.content
					}
					console.log("修改充值规则",data);
					addRechargeRule(getJsencryptRestlt(data)).then((response) => {
						if(response.code==200){
							this.$notify({
							  title: '成功',
							  message: '修改成功',
							  type: 'success',
							  duration: 2000
							})
							setTimeout(() => {
								this.closeSelectedTag();
							}, 1.2 * 1000)
						}
		      })
		    }
		  })
		},
  }
}
</script>

<style scoped>
.dialog-footer{
	width: 10.666666rem;
}
.dialog-footer button{
	margin: 0 auto;
	display: block;
}
.tinymce-container {
  position: relative;
  line-height: normal;
}
.tinymce-container>>>.mce-fullscreen {
  z-index: 10000;
}
.tinymce-textarea {
	width: 500px;
  visibility: hidden;
  z-index: -1;
}
.editor-custom-btn-container {
  position: absolute;
  right: 4px;
  top: 4px;
  /*z-index: 2005;*/
}
.fullscreen .editor-custom-btn-container {
  z-index: 10000;
  position: fixed;
}
.editor-upload-btn {
  display: inline-block;
}
</style>
