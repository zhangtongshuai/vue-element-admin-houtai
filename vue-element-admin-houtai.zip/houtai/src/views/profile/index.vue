<template>
  <div class="app-container">
    <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="100px" style="width: 400px; margin-left:50px;">
      <el-form-item label="原密码" prop="oldpsd">
        <el-input v-model="temp.oldpsd" type="password"/>
      </el-form-item>
      <el-form-item label="新密码" prop="newpsd">
				<el-input v-model="temp.newpsd" type="password"/>
      </el-form-item>
      <el-form-item label="确认新密码" prop="confrimnewpsd">
      	<el-input v-model="temp.confrimnewpsd" type="password"/>
      </el-form-item>
			<el-form-item label="验证码" prop="authcode">
				<div style="display: flex;flex-direction: row;justify-content: space-between;">
					<el-input v-model="temp.authcode" type="password" style="width: 40%;"/>
					<el-button type="primary" :disabled="codeDisabled"  @click="getPhoneCode()">{{codeMsg}}</el-button>
				</div>
			</el-form-item>
			<div class="code">{{codemsg}}</div>
    </el-form>
		<div slot="footer" class="dialog-footer">
		  <el-button type="primary" @click="updatePassword()">修改</el-button>
		</div>
  </div>
</template>

<script>
import { sendMeg,editPassword} from '@/api/api'
import { getJsencryptRestlt } from '@/api/getResylt'
import { MessageBox, Message } from 'element-ui'

export default {
  name: 'proflie',
  data() {
    return {
		temp: {
			oldpsd: '', //原密码
			newpsd:'', //新密码
			confrimnewpsd:'', //确认新密码
		},
		codeMsg:'获取验证码',
		codeDisabled:false,
		countdown:60,
		codemsg:'',
		timer: null,
		rules: {
			oldpsd: [{ required: true, message: '请输入原密码', trigger: 'blur' }],
			newpsd: [{ required: true, message: '请输入新密码', trigger: 'blur' }],
			confrimnewpsd: [{required: true, message: '请确认新密码', trigger: 'blur' }],
			authcode:[{required: true, message: '请输入验证码', trigger: 'blur' }]
		},
    }
  },
  created() {
		
  },
  methods: {
	//获取手机验证码
	getPhoneCode(){
		var phone=this.phone;
		var currentTime = this.currentTime;
		if (!this.timer) {
			this.timer = setInterval(() => {
				if (this.countdown > 0 && this.countdown <= 60) {
					this.countdown--;
					if (this.countdown !== 0) {
						this.codeMsg = "重新发送(" + this.countdown + ")";
					} else {
						clearInterval(this.timer);
						this.codeMsg = "获取验证码";
						this.countdown = 60;
						this.timer = null;
						this.codeDisabled = false;
					}
				}
			}, 1000);
			sendMeg().then((response) => {
				console.log(response)
				if(response.code==200){
					var phone=response.data;
					this.codemsg='验证码已发送到'+phone;
					this.$notify({
					  title: '成功',
					  message: '验证码发送成功',
					  type: 'success',
					  duration: 2000
					})
				}
			});
		}
	},
	//修改密码
    updatePassword() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
			if(this.temp.newpsd!=this.temp.confrimnewpsd){
				Message({
				  message: '两次输入密码不一致',
				  type: 'error',
				  duration: 5 * 1000
				})
			}else{
				var data={
					oldPassword:this.temp.oldpsd,
					newPassword:this.temp.newpsd,
					authcode:this.temp.authcode
				}
				//修改密码
				console.log(getJsencryptRestlt(data));
				editPassword(data).then((response) => {
				  if(response.code=200){
					 this.$notify({
						title: '成功',
						message: '修改密码成功,请重新登录',
						type: 'success',
						duration: 2000
					 })
					setTimeout(() => {
					  this.logout();
					}, 1.5 * 1000) 
				  }
				})
			}
        }
      })
    },
	//退出登录
	async logout() {
	  await this.$store.dispatch('user/logout')
	  this.$router.push(`/login?redirect=${this.$route.fullPath}`)
	}
  }
}
</script>
<style scoped="scoped">
	.dialog-footer{
		width: 10.666666rem;
	}
	.dialog-footer button{
		margin: 0 auto;
		display: block;
	}
	.code{
		text-align: center;
		margin-bottom: 30px;
		font-size: 15px;
	}
</style>
